# Automating VPN Connectivity Between AWS and GCP with Terraform

This project provides Terraform code to automate the setup of a secure VPN connection between an Amazon Web Services (AWS) Virtual Private Cloud (VPC) and a Google Cloud Platform (GCP) Virtual Private Cloud (VPC).

![AWS to GCP VPN Diagram](assets/aws-to-gcp-vpn-light.svg)

## Project Structure

```
.
└── terraform
    └── modules
        ├── aws
        │   ├── network
        │   ├── vm
        │   └── vpn
        └── gcp
            ├── network
            ├── vm
            └── vpn
```

## Prerequisites

Before you begin, ensure you have the following:

*   **Terraform:** Version 1.0 or later.
*   **AWS Account:** An active AWS account with the necessary permissions to create VPCs, VPN gateways, and other related resources.
*   **GCP Account:** An active GCP account with a project and the necessary permissions to create VPCs, VPN gateways, and other related resources.
*   **AWS Credentials:** Your AWS credentials configured in a way that Terraform can use them (e.g., via environment variables or the `~/.aws/credentials` file).
*   **GCP Credentials:** Your GCP credentials configured for Terraform (e.g., via a service account key file and the `GOOGLE_APPLICATION_CREDENTIALS` environment variable).

## Configuration

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd aws-to-gcp-vpn
    ```

2.  **Configure variables:**
    Create a `terraform.tfvars` file in the `terraform` directory and populate it with your desired values. You can use `terraform.tfvars.example` as a template:
    ```bash
    cp terraform/terraform.tfvars.example terraform/terraform.tfvars
    ```
    Now, edit `terraform/terraform.tfvars` with your specific configuration.

3.  **Configure the backend (Optional but recommended):**
    To store your Terraform state remotely, configure a backend in your `terraform/versions.tf` file. An example using a GCS bucket is provided in `terraform/versions.tf.example`.

    - Create a GCS bucket for your Terraform state.
    - Add the backend configuration to `terraform/versions.tf`:
      ```terraform
      terraform {
        backend "gcs" {
          bucket  = "<your-bucket-for-terraform-state>"
          prefix  = "terraform/state"
        }
      }
      ```

## Usage

1.  **Initialize Terraform:**
    Navigate to the `terraform` directory and run `terraform init`. This will download the necessary providers and initialize the backend.
    ```bash
    cd terraform
    terraform init
    ```

2.  **Plan the deployment:**
    Run `terraform plan` to see the resources that will be created.
    ```bash
    terraform plan -var-file="terraform.tfvars"
    ```

3.  **Apply the configuration:**
    If the plan looks correct, apply the configuration to create the infrastructure.
    ```bash
    terraform apply -var-file="terraform.tfvars"
    ```

## Cleanup

To tear down the infrastructure and remove all resources created by this project, run the following command:

```bash
terraform destroy -var-file="terraform.tfvars"
```

## VPN Status

### AWS Console

*Screenshots of the VPN connection status in the AWS console.*

#### VPN connection 1
![AWS VPN Status](assets/aws-vpn1.png)

#### VPN connection 2
![AWS VPN Status](assets/aws-vpn2.png)

### GCP Console

*Screenshot of the VPN connection status in the GCP console.*

![GCP VPN Status](assets/gcp-vpn.png)

## Verifying the Connection

Here you can see screenshots of the successful ping tests between the private ip of each instances.

#### EC2 to GCE Ping

![EC2 to GCE Ping](assets/ec2-to-gce-ping.png)

#### GCE to EC2 Ping

![GCE to EC2 Ping](assets/gce-to-ec2-ping.png)

## Reference
*   **Google Cloud:** [Creating HA VPN connections between Google Cloud and AWS](https://cloud.google.com/network-connectivity/docs/vpn/tutorials/create-ha-vpn-connections-google-cloud-aws)
*   **AWS:** [What is AWS Site-to-Site VPN?](https://docs.aws.amazon.com/vpn/latest/s2svpn/VPC_VPN.html)

### Terraform

*   **Providers:**
    *   [AWS Provider Documentation](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
    *   [Google Cloud Provider Documentation](https://registry.terraform.io/providers/hashicorp/google/latest/docs)
